﻿using System.Text;

namespace Methods
{
    public class StringRepeater
    {
        public static string RepeatString(string[] words, char letter)
        {
            if (words.Length == 0)
            {
                return string.Empty;
            }

            StringBuilder output = new StringBuilder();
            string repeatedWord;
            string currentWord;

            for (int i = 0; i < words.Length; i++)
            {
                currentWord = words[i];
                char firstLetter = Convert.ToChar(currentWord[0]);

                if (firstLetter == letter)
                {
                    repeatedWord = string.Concat(Enumerable.Repeat(currentWord, currentWord.Length));
                    output.Append(repeatedWord);
                }
            }

            return output.ToString();
        }
    }
}
