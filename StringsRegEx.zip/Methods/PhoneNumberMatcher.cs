﻿using System.Text.RegularExpressions;

namespace Methods
{
    public class PhoneNumberMatcher
    {
        public static string MatchPhones(string phones)
        {
            Regex pattern = new(@"\+359(?<separators>[ -])899\k<separators>[0-9]{3}\k<separators>[0-9]{3}\b");
            MatchCollection matches = pattern.Matches(phones);

            return string.Join(", ", matches.Select(x => x.Value.Trim()).ToArray());
        }
    }
}
