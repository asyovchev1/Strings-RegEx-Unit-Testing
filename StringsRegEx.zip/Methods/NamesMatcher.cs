﻿using System.Text.RegularExpressions;
using System.Text;

namespace Methods
{
    public class NamesMatcher
    {
        public static string MatchNames(string names)
        {
            Regex pattern = new(@"\b[A-Z][a-z]+ [A-Z][a-z]+");

            MatchCollection matches = pattern.Matches(names);

            StringBuilder sb = new();
            foreach (Match match in matches)
            {
                sb.Append($"{match.Value} ");
            }

            return sb.ToString().Trim();
        }
    }
}
