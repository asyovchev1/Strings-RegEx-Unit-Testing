﻿namespace Methods
{
    public class StringConverter
    {
        public static string ConvertString(string input)
        {
            char[] letters = input.ToCharArray();

            for (int i = 0; i <  letters.Length; i++) 
            { 
                if (letters[i] >= 65 && letters[i] <= 90)
                {
                    letters[i] = Convert.ToChar(letters[i] + 32);
                }
                else
                {
                    if (letters[i] >= 97 && letters[i] <= 122)
                    {
                        letters[i] = Convert.ToChar(letters[i] - 32);
                    }
                }
            }

            return new string(letters);
        }
    }
}
