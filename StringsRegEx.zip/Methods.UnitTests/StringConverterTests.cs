﻿namespace Methods.UnitTests
{
    public class StringConverterTests
    {
        [Test, Order(1)]
        public void Test_ConvertString_EmptyString_ReturnEmptyString()
        {
            //Arrange
            string input = string.Empty;

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test, Order(2)]
        public void Test_ConvertString_LowerCaseString_ReturnUpperCaseString()
        {
            //Arrange
            string input = "apple";

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo("APPLE"));
        }

        [Test, Order(3)]
        public void Test_ConvertString_UpperCaseString_ReturnLowerCaseString()
        {
            //Arrange
            string input = "BANANA";

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo("banana"));
        }

        [Test, Order(4)]
        public void Test_ConvertString_MixedCaseString_ReturnOppositeCaseString()
        {
            //Arrange
            string input = "kIWi";

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo("KiwI"));
        }

        [Test, Order(5)]
        public void Test_ConvertString_MixedCaseStrings_ReturnOppositeCaseStrings()
        {
            //Arrange
            string input = "kIWi oRaNGe";

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo("KiwI OrAngE"));
        }

        [Test, Order(6)]
        public void Test_ConvertString_NumbersString_ReturnSameString()
        {
            //Arrange
            string input = "123456";

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo("123456"));
        }

        [Test, Order(7)]
        public void Test_ConvertString_SpecialSymbolsString_ReturnSameString()
        {
            //Arrange
            string input = "!@#$%^";

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo("!@#$%^"));
        }

        [Test, Order(8)]
        public void Test_ConvertString_AllMixedString_ReturnOppositeLettersString()
        {
            //Arrange
            string input = "!a@P#p$L%e^ %b*A&n^A$N(A";

            //Act
            string result = StringConverter.ConvertString(input);

            //Assert
            Assert.That(result, Is.EqualTo("!A@p#P$l%E^ %B*a&N^a$n(a"));
        }
    }
}
