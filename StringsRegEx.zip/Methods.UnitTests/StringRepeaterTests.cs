namespace Methods.UnitTests
{
    public class StringRepeaterTests
    {
        [Test, Order(1)]
        public void Test_RepeatString_EmptyArray_ReturnEmptyString()
        {
            //Arrange
            string[] input = new string[] { };

            //Act
            string result = StringRepeater.RepeatString(input, 'c');

            //Assert
            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test, Order(2)]
        public void Test_RepeatString_NonMatchingWord_ReturnEmptyString()
        {
            //Arrange
            string[] input = new string[] { "apple" };

            //Act
            string result = StringRepeater.RepeatString(input, 'c');

            //Assert
            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test, Order(3)]
        public void Test_RepeatString_NonMatchingWords_ReturnEmptyString()
        {
            //Arrange
            string[] input = new string[] { "apple" , "banana" };

            //Act
            string result = StringRepeater.RepeatString(input, 'c');

            //Assert
            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test, Order(4)]
        public void Test_RepeatString_MatchingSingleWord_ReturnRepeatedWord()
        {
            //Arrange
            string[] input = new string[] { "apple" };

            //Act
            string result = StringRepeater.RepeatString(input, 'a');

            //Assert
            Assert.That(result, Is.EqualTo("appleappleappleappleapple"));
        }

        [Test, Order(5)]
        public void Test_RepeatString_MatchingMultipleWords_ReturnRepeatedWords()
        {
            //Arrange
            string[] input = new string[] { "ap", "ab" };

            //Act
            string result = StringRepeater.RepeatString(input, 'a');

            //Assert
            Assert.That(result, Is.EqualTo("apapabab"));
        }

        [Test, Order(6)]
        public void Test_RepeatString_MatchingMultipleWordsWithSpace_ReturnRepeatedWordsWithSpace()
        {
            //Arrange
            string[] input = new string[] { "ap ab", "ac" };

            //Act
            string result = StringRepeater.RepeatString(input, 'a');

            //Assert
            Assert.That(result, Is.EqualTo("ap abap abap abap abap abacac"));
        }

        [Test, Order(7)]
        public void Test_RepeatString_FirstMatchingWord_ReturnRepeatedFirstWord()
        {
            //Arrange
            string[] input = new string[] { "apple", "banana" };

            //Act
            string result = StringRepeater.RepeatString(input, 'a');

            //Assert
            Assert.That(result, Is.EqualTo("appleappleappleappleapple"));
        }

        [Test, Order(8)]
        public void Test_RepeatString_OtherMatchingWord_ReturnRepeatedOtherWord()
        {
            //Arrange
            string[] input = new string[] { "apple", "banana" };

            //Act
            string result = StringRepeater.RepeatString(input, 'b');

            //Assert
            Assert.That(result, Is.EqualTo("bananabananabananabananabananabanana"));
        }
    }
}