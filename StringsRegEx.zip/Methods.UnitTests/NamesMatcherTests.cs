﻿namespace Methods.UnitTests
{
    public class NamesMatcherTests
    {
        [Test, Order(1)]
        public void Test_MatchNames_EmptyInput_ReturnsEmptyString()
        {
            //Arrange
            string names = "";
            string expected = string.Empty;

            // Act
            string result = NamesMatcher.MatchNames(names);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }

        [Test, Order(2)]
        public void Test_MatchNames_NoValidNames_ReturnsEmptyString()
        {
            //Arrange
            string names = "asdabs sdsdl";
            string expected = string.Empty;

            // Act
            string result = NamesMatcher.MatchNames(names);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }

        [Test, Order(3)]
        public void Test_MatchNames_ValidName_ReturnsMatchedName()
        {
            // Arrange
            string names = "Ivan Ivanov";
            string expected = "Ivan Ivanov";

            // Act
            string result = NamesMatcher.MatchNames(names);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }

        [Test, Order(4)]
        public void Test_MatchNames_ValidNames_ReturnsMatchedNames()
        {
            // Arrange
            string names = "Ivan Ivanov and Helen Smith";
            string expected = "Ivan Ivanov Helen Smith";

            // Act
            string result = NamesMatcher.MatchNames(names);

            // Assert
            Assert.That(result, Is.EqualTo(expected));
        }
    }
}
