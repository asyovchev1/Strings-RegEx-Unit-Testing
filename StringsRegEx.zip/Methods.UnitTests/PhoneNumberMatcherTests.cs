﻿namespace Methods.UnitTests
{
    public class PhoneNumberMatcherTests
    {
        [Test, Order(1)]
        public void Test_MatchPhones_EmptyInput_ReturnsEmptyString()
        {
            // Arrange
            string phoneNumbers = "";

            // Act
            string result = PhoneNumberMatcher.MatchPhones(phoneNumbers);

            // Assert
            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test, Order(2)]
        public void Test_MatchPhones_NoValidPhoneNumbers_ReturnsEmptyString()
        {
            // Arrange
            string phoneNumbers = "+359877342690, +359*886*435*801, +359\\892\\333\\333";

            // Act
            string result = PhoneNumberMatcher.MatchPhones(phoneNumbers);

            // Assert
            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test, Order(3)]
        public void Test_MatchPhones_ValidPhoneNumbers_ReturnsMatchedNumbers()
        {
            // Arrange
            string phoneNumbers = "+359-899-654-338, +359 899 486 231, +359-899-777-777";

            // Act
            string result = PhoneNumberMatcher.MatchPhones(phoneNumbers);

            // Assert
            Assert.That(result, Is.EqualTo("+359-899-654-338, +359 899 486 231, +359-899-777-777"));
        }

        [Test, Order(4)]
        public void Test_MatchPhones_MixedValidAndInvalidNumbers_ReturnsOnlyValidNumbers()
        {
            // Arrange
            string phoneNumbers = "+359877342690, +359-899-411-689, +359\\892\\333\\333";

            // Act
            string result = PhoneNumberMatcher.MatchPhones(phoneNumbers);

            // Assert
            Assert.That(result, Is.EqualTo("+359-899-411-689"));
        }
    }
}
